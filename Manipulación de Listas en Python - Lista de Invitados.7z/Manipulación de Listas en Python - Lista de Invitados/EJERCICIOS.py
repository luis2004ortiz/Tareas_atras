
# Lista de invitados
invitados = ["Jermy", "Luis", "Sara"]

# Mensajes personalizados de invitación
print(f"Hola {invitados[0]}, ¿te gustaría venir a cenar esta noche?")
print(f"Hola {invitados[1]}, ¿te gustaría venir a cenar esta noche?")
print(f"Hola {invitados[2]}, ¿te gustaría venir a cenar esta noche?")

# Jermy no puede asistir
print(f"{invitados[0]} no podrá asistir a la cena.")

# Reemplazamos a Jermy por Joleidy
invitados[0] = "Joleidy"

# Nuevas invitaciones
print(f"Hola {invitados[0]}, ¿te gustaría venir a cenar esta noche?")
print(f"Hola {invitados[1]}, ¿te gustaría venir a cenar esta noche?")
print(f"Hola {invitados[2]}, ¿te gustaría venir a cenar esta noche?")

print("¡Buenas noticias! Hemos conseguido una mesa más grande.")

# Agregar invitados en distintas posiciones
invitados.insert(0, "David")
invitados.insert(2, "Camila")
invitados.append("Esteban")

# Nuevas invitaciones para todos
for persona in invitados:
    print(f"{persona}, estás cordialmente invitado a la cena.")

print("Lamentablemente, la mesa grande no estará disponible. Solo podemos invitar a dos personas.")

# Eliminar invitados hasta que queden solo dos
while len(invitados) > 2:
    eliminado = invitados.pop()
    print(f"Lo siento {eliminado}, no podrás asistir a la cena.")

# Confirmación a los dos invitados restantes
for persona in invitados:
    print(f"{persona}, aún estás invitado a la cena.")

# Vaciar la lista
del invitados[0]
del invitados[0]

# Verificar que la lista está vacía
print("Lista final de invitados:", invitados)
