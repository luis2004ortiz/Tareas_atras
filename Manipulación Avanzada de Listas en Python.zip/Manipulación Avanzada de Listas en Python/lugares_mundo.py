# Lista original de lugares por visitar
lugares = ["Venecia", "Islas Galápagos", "Kioto", "Nueva York", "Petra"]
# Mostrar la lista original
print("Lista original:", lugares)
# Mostrar la lista en orden alfabético sin modificar la original
print("Orden alfabético (temporal):", sorted(lugares))
# Confirmar que la lista no se modificó
print("Lista original después de sorted():", lugares)
# Mostrar la lista en orden alfabético inverso (temporal)
print("Orden alfabético inverso (temporal):", sorted(lugares, reverse=True))
# Confirmar que la lista no se modificó
print("Lista original después de sorted(reverse=True):", lugares)

# Invertir la lista
lugares.reverse()
print("Lista invertida:", lugares)

# Volver al orden original
lugares.reverse()
print("Lista restaurada:", lugares)

# Ordenar permanentemente
lugares.sort()
print("Lista ordenada permanentemente:", lugares)

# Ordenar de forma inversa permanentemente
lugares.sort(reverse=True)
print("Lista ordenada inversamente permanentemente:", lugares)
