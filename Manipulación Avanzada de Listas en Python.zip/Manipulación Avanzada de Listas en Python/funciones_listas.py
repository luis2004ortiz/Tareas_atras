# Lista original de países
paises = ["Ecuador", "Korea", "Canadá", "Brasil", "Alemania"]

# Usando append()
paises.append("Francia")
print("Después de append():", paises)

# Usando insert()
paises.insert(2, "México")
print("Después de insert():", paises)

# Usando del
del paises[1]
print("Después de del:", paises)

# Usando pop()
eliminado = paises.pop()
print(f"País eliminado con pop(): {eliminado}")
print("Lista actual:", paises)

# Usando remove()
paises.remove("Canadá")
print("Después de remove():", paises)

# Usando sorted()
print("Lista ordenada temporalmente:", sorted(paises))

# Usando sort()
paises.sort()
print("Lista ordenada permanentemente:", paises)

# Usando reverse()
paises.reverse()
print("Lista invertida:", paises)

# Usando len()
print("Cantidad de elementos:", len(paises))
