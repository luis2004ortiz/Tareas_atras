# Lista de invitados
invitados = ["Jermy", "Luis", "Sara", "Joleidy"]

# Mostrar número de invitados
print(f"Se han invitado a {len(invitados)} personas a cenar.")
