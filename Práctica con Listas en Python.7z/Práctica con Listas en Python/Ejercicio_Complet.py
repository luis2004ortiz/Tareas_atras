# Lista de nombres de amigos
nombres = ["Jermy", "Luis", "Sara", "Joleidy"]

# Imprimir cada nombre individualmente
print(nombres[0])
print(nombres[1])
print(nombres[2])
print(nombres[3])

# Saludos personalizados
print(f"Hola {nombres[0]}, ¿cómo has estado?")
print(f"Hola {nombres[1]}, ¿cómo has estado?")
print(f"Hola {nombres[2]}, ¿cómo has estado?")
print(f"Hola {nombres[3]}, ¿cómo has estado?")


# Lista de transportes
transportes = ["motocicleta Honda", "automóvil Tesla", "bicicleta BMX", "camioneta Toyota"]

# Frases con los transportes
print(f"Me gustaría tener una {transportes[0]}.")
print(f"Me gustaría tener un {transportes[1]}.")
print(f"Me gustaría tener una {transportes[2]}.")
print(f"Me gustaría tener una {transportes[3]}.")


# Mensajes combinando nombres y transportes
print(f"Felicidades {nombres[0]}, has comprado una {transportes[0]}")
print(f"Felicidades {nombres[1]}, has comprado un {transportes[1]}")
print(f"Felicidades {nombres[2]}, has comprado una {transportes[2]}")
print(f"Felicidades {nombres[3]}, has comprado una {transportes[3]}")

